# QuantSwarm-Alpha-Zero — repository completa con Kimi

Il motore decisionale è **Kimi K3.1 Pro Highspeed** tramite Moonshot API. Alpaca gestisce market data ed esecuzione. Tutti i file necessari sono riportati integralmente, senza credenziali, sezioni eluse o TODO.

## Note tecniche vincolanti

- Kimi K3.1 Pro usa parametri di campionamento fissi: il client omette `temperature` e usa `response_format` con JSON Schema rigido.
- iOS può sospendere WebSocket e processi in background. `BGTaskScheduler` e CoreLocation sono implementati nei limiti di sistema, senza simulare navigazione e senza promettere un loop 24/7.
- Le generic password protette da Face ID risiedono nel Keychain; non diventano chiavi private non esportabili del Secure Enclave.
- L’IPA prodotto è non firmato. La firma finale e gli entitlement disponibili dipendono dal profilo usato per il sideloading.
- Il rischio teorico per ordine è limitato, ma gap, liquidità e malfunzionamenti possono causare perdite superiori. La modalità paper è predefinita; nessun rendimento è garantito.

## Struttura della repository

```text
QuantSwarm-Alpha-Zero/
├── project.yml
├── README.md
├── .gitignore
├── .github/
│   └── workflows/
│       └── ios-build.yml
└── Sources/
    ├── App/
    │   └── QuantSwarmAlphaZeroApp.swift
    ├── Models/
    │   └── TradingModels.swift
    ├── Managers/
    │   └── KeychainManager.swift
    ├── Services/
    │   ├── KimiService.swift
    │   └── AlpacaService.swift
    ├── Agents/
    │   ├── MarketScoutAgent.swift
    │   └── RiskExecutionAgent.swift
    ├── Core/
    │   ├── BackgroundPersistenceManager.swift
    │   └── QuantSwarmEngine.swift
    └── Views/
        ├── LoginView.swift
        └── TerminalDashboardView.swift
```

## File completi

### `project.yml`

````yaml
name: QuantSwarmAlphaZero
options:
  bundleIdPrefix: com.quantswarm
  deploymentTarget:
    iOS: "17.0"
  createIntermediateGroups: true
  groupSortPosition: top
settings:
  base:
    SWIFT_VERSION: "6.0"
    SWIFT_STRICT_CONCURRENCY: complete
    ENABLE_USER_SCRIPT_SANDBOXING: YES
    DEAD_CODE_STRIPPING: YES
  configs:
    Debug:
      SWIFT_OPTIMIZATION_LEVEL: "-Onone"
    Release:
      SWIFT_OPTIMIZATION_LEVEL: "-O"
      SWIFT_COMPILATION_MODE: wholemodule
      OTHER_SWIFT_FLAGS: "$(inherited) -whole-module-optimization"
targets:
  QuantSwarmAlphaZero:
    type: application
    platform: iOS
    deploymentTarget: "17.0"
    sources:
      - path: Sources
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: com.quantswarm.alphazero
        PRODUCT_NAME: QuantSwarmAlphaZero
        MARKETING_VERSION: "1.0.0"
        CURRENT_PROJECT_VERSION: "1"
        GENERATE_INFOPLIST_FILE: NO
        TARGETED_DEVICE_FAMILY: "1"
        SUPPORTS_MACCATALYST: NO
        ENABLE_BITCODE: NO
    dependencies:
      - sdk: AVFoundation.framework
      - sdk: CoreLocation.framework
      - sdk: Security.framework
      - sdk: SwiftUI.framework
      - sdk: SwiftData.framework
    info:
      path: Generated/Info.plist
      properties:
        CFBundleDisplayName: QuantSwarm Alpha Zero
        UILaunchScreen: {}
        UIRequiredDeviceCapabilities: [arm64]
        UISupportedInterfaceOrientations: [UIInterfaceOrientationPortrait]
        UIBackgroundModes: [location, fetch, remote-notification]
        BGTaskSchedulerPermittedIdentifiers: [com.quantswarm.alphazero.refresh]
        NSFaceIDUsageDescription: "Face ID protegge l'accesso alle credenziali API salvate nel Keychain."
        NSLocationWhenInUseUsageDescription: "La posizione è usata solo durante la sessione di trading esplicitamente avviata; non viene simulata alcuna navigazione."
        NSLocationAlwaysAndWhenInUseUsageDescription: "L'accesso continuo consente aggiornamenti di sessione in background quando consentiti da iOS; non garantisce un WebSocket permanente."
        ITSAppUsesNonExemptEncryption: false
    entitlements:
      path: Generated/QuantSwarmAlphaZero.entitlements
      properties:
        aps-environment: development
    scheme:
      gatherCoverageData: false
schemes:
  QuantSwarmAlphaZero:
    build:
      targets:
        QuantSwarmAlphaZero: all
    run:
      config: Debug
    profile:
      config: Release
    analyze:
      config: Debug
    archive:
      config: Release
````

### `.github/workflows/ios-build.yml`

````yaml
name: Unsigned iOS IPA

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build:
    runs-on: macos-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Install XcodeGen
        run: |
          brew update
          brew install xcodegen
          xcodegen --version

      - name: Generate Xcode project
        run: xcodegen generate --spec project.yml

      - name: Build unsigned Release app
        run: |
          xcodebuild \
            -project QuantSwarmAlphaZero.xcodeproj \
            -scheme QuantSwarmAlphaZero \
            -configuration Release \
            -sdk iphoneos \
            -destination 'generic/platform=iOS' \
            -derivedDataPath "$PWD/DerivedData" \
            CODE_SIGNING_ALLOWED=NO \
            CODE_SIGNING_REQUIRED=NO \
            CODE_SIGN_IDENTITY="" \
            PROVISIONING_PROFILE_SPECIFIER="" \
            clean build

      - name: Package unsigned IPA
        run: |
          APP_PATH="$PWD/DerivedData/Build/Products/Release-iphoneos/QuantSwarmAlphaZero.app"
          test -d "$APP_PATH"
          mkdir -p Package/Payload
          ditto "$APP_PATH" "Package/Payload/QuantSwarmAlphaZero.app"
          cd Package
          zip -qry QuantSwarm-Alpha-Zero.ipa Payload
          unzip -t QuantSwarm-Alpha-Zero.ipa

      - name: Upload IPA artifact
        uses: actions/upload-artifact@v4
        with:
          name: QuantSwarm-Alpha-Zero-unsigned
          path: Package/QuantSwarm-Alpha-Zero.ipa
          if-no-files-found: error
          retention-days: 14
````

### `README.md`

````markdown
# QuantSwarm-Alpha-Zero

Applicazione iOS 17+ in Swift 6, SwiftUI e SwiftData. Kimi (`kimi-k3.1-pro-highspeed`) genera segnali JSON vincolati; Alpaca fornisce market data IEX, conto, ordini bracket e liquidazione. Il progetto non contiene credenziali.

## Build e artifact

1. Mantieni la struttura della repository e effettua il push sul branch `main`.
2. GitHub Actions installa XcodeGen, genera il progetto e compila con `CODE_SIGNING_ALLOWED=NO`.
3. Scarica l'artifact `QuantSwarm-Alpha-Zero-unsigned`, contenente `QuantSwarm-Alpha-Zero.ipa`.
4. L'IPA è non firmato. AltStore e Sideloadly normalmente richiedono una fase di firma con un profilo valido; la compatibilità con TrollStore dipende da versione di iOS e metodo di installazione. Gli entitlement effettivi dipendono dal profilo usato per la firma finale.

Per una build locale su macOS:

```sh
brew install xcodegen
xcodegen generate --spec project.yml
xcodebuild -project QuantSwarmAlphaZero.xcodeproj -scheme QuantSwarmAlphaZero -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
```

## Avvio

1. Crea una API key Moonshot/Kimi sulla stessa piattaforma regionale dell'endpoint globale `https://api.moonshot.ai/v1`.
2. Usa inizialmente credenziali Alpaca paper. L'app convalida Kimi tramite `GET /v1/models` e Alpaca tramite `GET /v2/account` prima del salvataggio.
3. Inserisci simboli e news datate con fonte. Non è presente un aggregatore news automatico.
4. Attendi almeno 14 barre per il primo ATR. Il motore valuta ciascun simbolo al massimo una volta per ciclo di 60 secondi.
5. `STOP` ferma il motore senza chiudere posizioni. `HARD KILL SWITCH`, dopo conferma, cancella tutti gli ordini e richiede la chiusura a mercato di tutte le posizioni del conto configurato.

## Controlli implementati

- Keychain `kSecClassGenericPassword`, `kSecAccessControlBiometryAny`, `WhenUnlockedThisDeviceOnly`.
- JSON Schema Kimi rigido, parsing del solo `message.content`, sanificazione Markdown e validazione locale del segnale.
- WebSocket Alpaca con autenticazione, trade/barre, riconnessione con backoff e monitoraggio `NWPathMonitor`.
- ATR di Wilder su 14 barre; il valore viene riletto a ogni trade e aggiornato a ogni nuova barra.
- Kelly frazionato a un quarto, quantità intera, rischio massimo teorico dell'1%, controllo di feed e round-trip REST a 150 ms, deviazione massima dello 0,05%.
- Ordine bracket `limit` con take-profit e stop-loss server-side. Il limite riduce lo slippage ma non garantisce l'esecuzione né il prezzo dello stop in gap di mercato.
- Persistenza SwiftData degli ordini e aggiornamento degli esiti dai fill Alpaca. Il P&L calcolato non include commissioni o imposte non fornite dal broker.
- Un solo ordine/posizione per simbolo; nessuna mediazione o apertura duplicata.

## Limiti reali

- iOS decide quando eseguire BGTask e può sospendere WebSocket, rete e processi in background. Il codice non simula navigazione e non può garantire operatività 24/7. Per trading continuo serve un servizio server-side sempre attivo.
- Kimi K3.1 Pro usa temperatura fissa e reasoning sempre attivo; il connettore omette `temperature`. Nessun modello garantisce assenza di errori o rendimenti superiori.
- Il Keychain protegge i dati con le protezioni del dispositivo e Face ID, ma una generic password non diventa una chiave privata non esportabile nel Secure Enclave.
- Una API key usata direttamente da un'app distribuita è una credenziale lato cliente: non equivale a un segreto server-side. Usa chiavi con privilegi minimi e rotazione.
- La modalità live può causare perdite, inclusa perdita superiore al rischio teorico in caso di gap, rifiuti, liquidità insufficiente o indisponibilità del broker. Testare in paper trading non dimostra performance future.

## Riferimenti ufficiali

- Kimi K3.1 Pro: https://platform.moonshot.ai/docs/guide/kimi-k3-1-pro-quickstart
- Kimi JSON Mode: https://platform.moonshot.ai/docs/guide/use-json-mode-feature-of-kimi-api
- Alpaca streaming: https://docs.alpaca.markets/us/docs/streaming-market-data
- Alpaca ordini: https://docs.alpaca.markets/us/docs/orders-at-alpaca
- XcodeGen Project Spec: https://github.com/yonaskolb/XcodeGen/blob/master/Docs/ProjectSpec.md
- Apple BackgroundTasks: https://developer.apple.com/documentation/backgroundtasks
- Swift Concurrency: https://docs.swift.org/latest/documentation/the-swift-programming-language/concurrency
````

### `.gitignore`

````gitignore
# Xcode and XcodeGen
QuantSwarmAlphaZero.xcodeproj/
Generated/
DerivedData/
build/
Build/
Package/
*.xcuserstate
xcuserdata/
*.xcworkspace/xcuserdata/
*.xcodeproj/xcuserdata/

# Swift Package Manager
.swiftpm/
.build/
Package.resolved

# macOS
.DS_Store
.AppleDouble
.LSOverride

# Credentials and local configuration
.env
.env.*
*.pem
*.p12
*.mobileprovision
*.key
secrets/
Credentials.swift

# Archives and temporary files
*.ipa
*.dSYM.zip
*.dSYM
*.tmp
*.log
````

### `Sources/App/QuantSwarmAlphaZeroApp.swift`

````swift
import SwiftUI
import SwiftData

@main
struct QuantSwarmAlphaZeroApp: App {
    @StateObject private var engine: QuantSwarmEngine
    private let container: ModelContainer

    init() {
        let keychain = KeychainManager()
        let background = BackgroundPersistenceManager()
        background.registerBackgroundTasks()
        do {
            container = try ModelContainer(for: TradeRecord.self)
            let engine = QuantSwarmEngine(
                keychain: keychain,
                background: background,
                container: container
            )
            _engine = StateObject(wrappedValue: engine)
        } catch {
            fatalError("Impossibile inizializzare SwiftData: \(error.localizedDescription)")
        }
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(engine)
                .modelContainer(container)
                .preferredColorScheme(.dark)
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var engine: QuantSwarmEngine

    var body: some View {
        Group {
            if engine.isConfigured {
                TerminalDashboardView()
            } else {
                LoginView()
            }
        }
        .task {
            await engine.restoreCredentials()
        }
    }
}
````

### `Sources/Models/TradingModels.swift`

````swift
import Foundation
import SwiftData

enum TradeAction: String, Codable, Sendable {
    case buy
    case sell
    case hold
}

struct KimiDecision: Codable, Sendable {
    let symbol: String
    let action: TradeAction
    let confidence: Double
    let entryPrice: Double
    let stopLoss: Double
    let takeProfit: Double
    let winProbability: Double
    let payoffRatio: Double
    let rationale: String

    enum CodingKeys: String, CodingKey {
        case symbol
        case action
        case confidence
        case entryPrice = "entry_price"
        case stopLoss = "stop_loss"
        case takeProfit = "take_profit"
        case winProbability = "win_probability"
        case payoffRatio = "payoff_ratio"
        case rationale
    }

    var isExecutable: Bool {
        guard action != .hold,
              confidence >= 0.55,
              entryPrice > 0,
              stopLoss > 0,
              takeProfit > 0,
              winProbability > 0,
              winProbability < 1,
              payoffRatio > 0 else {
            return false
        }
        return action == .buy
            ? stopLoss < entryPrice && entryPrice < takeProfit
            : takeProfit < entryPrice && entryPrice < stopLoss
    }
}

struct MarketSnapshot: Sendable {
    let symbol: String
    let lastPrice: Double
    let atr14: Double?
    let sourceTimestamp: Date
    let receivedAt: Date

    var feedLatencyMilliseconds: Double {
        max(0, receivedAt.timeIntervalSince(sourceTimestamp) * 1_000)
    }
}

struct StoredCredentials: Codable, Sendable {
    let moonshotAPIKey: String
    let alpacaKeyID: String
    let alpacaSecretKey: String
    let paperTrading: Bool

    var alpaca: AlpacaCredentials {
        AlpacaCredentials(
            keyID: alpacaKeyID,
            secretKey: alpacaSecretKey,
            paperTrading: paperTrading
        )
    }
}

struct AlpacaCredentials: Sendable {
    let keyID: String
    let secretKey: String
    let paperTrading: Bool

    var tradingBaseURL: URL {
        URL(string: paperTrading
            ? "https://paper-api.alpaca.markets"
            : "https://api.alpaca.markets")!
    }

    var marketDataStreamURL: URL {
        URL(string: "wss://stream.data.alpaca.markets/v2/iex")!
    }
}

struct AccountSnapshot: Decodable, Sendable {
    let cash: String
    let equity: String
    let buyingPower: String
    let tradingBlocked: Bool
    let tradeSuspendedByEmail: Bool

    enum CodingKeys: String, CodingKey {
        case cash
        case equity
        case buyingPower = "buying_power"
        case tradingBlocked = "trading_blocked"
        case tradeSuspendedByEmail = "trade_suspended_by_email"
    }

    var cashValue: Double { Double(cash) ?? 0 }
    var equityValue: Double { Double(equity) ?? 0 }
    var buyingPowerValue: Double { Double(buyingPower) ?? 0 }
}

struct ExecutionReceipt: Sendable {
    let orderID: String
    let decision: KimiDecision
    let quantity: Double
    let equity: Double
    let measuredLatencyMilliseconds: Double
}

struct EdgePoint: Identifiable, Sendable {
    let id = UUID()
    let timestamp: Date
    let value: Double
}

struct PerformanceMatrix: Sendable {
    let submittedTrades: Int
    let completedTrades: Int
    let winRate: Double?
    let averageNetPnL: Double?
    let stopErrorVariance: Double?
    let recentOutcomes: [Double]
}

enum QuantSwarmError: LocalizedError {
    case credentialsMissing
    case invalidCredentialInput
    case invalidServerResponse(String)
    case httpStatus(Int, String)
    case invalidDecision(String)
    case riskRejected(String)
    case persistence(String)

    var errorDescription: String? {
        switch self {
        case .credentialsMissing:
            return "Credenziali non configurate."
        case .invalidCredentialInput:
            return "Tutti i campi credenziali sono obbligatori."
        case .invalidServerResponse(let message):
            return "Risposta non valida: \(message)"
        case .httpStatus(let status, let body):
            return "Errore HTTP \(status): \(body)"
        case .invalidDecision(let message):
            return "Segnale Kimi rifiutato: \(message)"
        case .riskRejected(let message):
            return "Ordine bloccato dal risk manager: \(message)"
        case .persistence(let message):
            return "Persistenza SwiftData: \(message)"
        }
    }
}

@Model
final class TradeRecord {
    var id: UUID
    var orderID: String
    var createdAt: Date
    var symbol: String
    var action: String
    var requestedQuantity: Double
    var expectedEntry: Double
    var actualEntry: Double?
    var stopLoss: Double
    var takeProfit: Double
    var expectedATR: Double
    var confidence: Double
    var rationale: String
    var netPnL: Double?
    var stopErrorVariance: Double?
    var outcomeRecorded: Bool

    init(receipt: ExecutionReceipt, atr: Double) {
        id = UUID()
        orderID = receipt.orderID
        createdAt = Date()
        symbol = receipt.decision.symbol
        action = receipt.decision.action.rawValue
        requestedQuantity = receipt.quantity
        expectedEntry = receipt.decision.entryPrice
        actualEntry = nil
        stopLoss = receipt.decision.stopLoss
        takeProfit = receipt.decision.takeProfit
        expectedATR = atr
        confidence = receipt.decision.confidence
        rationale = receipt.decision.rationale
        netPnL = nil
        stopErrorVariance = nil
        outcomeRecorded = false
    }
}
````

### `Sources/Managers/KeychainManager.swift`

````swift
import Foundation
import Security

actor KeychainManager {
    private let service = "com.quantswarm.alphazero.credentials"
    private let account = "primary"

    func save(data: Data) throws {
        var accessError: Unmanaged<CFError>?
        guard let accessControl = SecAccessControlCreateWithFlags(
            nil,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            .biometryAny,
            &accessError
        ) else {
            let error = accessError?.takeRetainedValue()
            throw QuantSwarmError.persistence(error?.localizedDescription ?? "Access Control non disponibile")
        }

        let deleteQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(deleteQuery as CFDictionary)

        let addQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecAttrAccessControl as String: accessControl,
            kSecValueData as String: data,
            kSecUseNoAuthenticationUI as String: false
        ]
        let status = SecItemAdd(addQuery as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw QuantSwarmError.persistence("SecItemAdd: \(status)")
        }
    }

    func read(prompt: String = "Sblocca QuantSwarm con Face ID") throws -> Data {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecUseOperationPrompt as String: prompt
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status != errSecItemNotFound else {
            throw QuantSwarmError.credentialsMissing
        }
        guard status == errSecSuccess, let data = result as? Data else {
            throw QuantSwarmError.persistence("SecItemCopyMatching: \(status)")
        }
        return data
    }

    func delete() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw QuantSwarmError.persistence("SecItemDelete: \(status)")
        }
    }
}
````

### `Sources/Services/KimiService.swift`

````swift
import Foundation

actor KimiService {
    private let apiKey: String
    private let model = "kimi-k3.1-pro-highspeed"
    private let endpoint = URL(string: "https://api.moonshot.ai/v1/chat/completions")!
    private let session: URLSession

    init(apiKey: String) {
        self.apiKey = apiKey
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 90
        configuration.timeoutIntervalForResource = 120
        configuration.waitsForConnectivity = true
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
    }

    func validateCredentials() async throws {
        let url = URL(string: "https://api.moonshot.ai/v1/models")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        _ = try await sendWithRetry(request)
    }

    func decide(
        snapshot: MarketSnapshot,
        news: String,
        performance: PerformanceMatrix
    ) async throws -> KimiDecision {
        let systemPrompt = """
        Sei il modulo decisionale di un sistema di trading. Non fornire consulenza finanziaria \
        e non affermare certezze. Valuta esclusivamente i dati forniti. Restituisci hold se i dati \
        sono insufficienti, incoerenti o il rapporto rischio/rendimento non è favorevole. Per buy \
        vale stop_loss < entry_price < take_profit; per sell vale take_profit < entry_price < \
        stop_loss. entry_price deve essere il prezzo corrente fornito. win_probability è una stima \
        soggettiva in (0,1), payoff_ratio è il rapporto reward/risk positivo. Non usare Markdown.
        """
        let payload: [String: Any] = [
            "market": [
                "symbol": snapshot.symbol,
                "last_price": snapshot.lastPrice,
                "atr_14": snapshot.atr14.map { $0 as Any } ?? NSNull(),
                "source_timestamp": ISO8601DateFormatter().string(from: snapshot.sourceTimestamp),
                "feed_latency_ms": snapshot.feedLatencyMilliseconds
            ],
            "news_text": news,
            "historical_performance": [
                "submitted_trades": performance.submittedTrades,
                "completed_trades": performance.completedTrades,
                "win_rate": performance.winRate.map { $0 as Any } ?? NSNull(),
                "average_net_pnl": performance.averageNetPnL.map { $0 as Any } ?? NSNull(),
                "stop_error_variance": performance.stopErrorVariance.map { $0 as Any } ?? NSNull(),
                "recent_outcomes": performance.recentOutcomes
            ]
        ]
        let payloadData = try JSONSerialization.data(withJSONObject: payload)
        let payloadString = String(decoding: payloadData, as: UTF8.self)
        let messages: [[String: String]] = [
            ["role": "system", "content": systemPrompt],
            ["role": "user", "content": payloadString]
        ]
        let schema: [String: Any] = [
            "type": "object",
            "properties": [
                "symbol": ["type": "string"],
                "action": ["type": "string", "enum": ["buy", "sell", "hold"]],
                "confidence": ["type": "number", "minimum": 0, "maximum": 1],
                "entry_price": ["type": "number", "exclusiveMinimum": 0],
                "stop_loss": ["type": "number", "minimum": 0],
                "take_profit": ["type": "number", "minimum": 0],
                "win_probability": ["type": "number", "exclusiveMinimum": 0, "exclusiveMaximum": 1],
                "payoff_ratio": ["type": "number", "exclusiveMinimum": 0],
                "rationale": ["type": "string"]
            ],
            "required": [
                "symbol", "action", "confidence", "entry_price", "stop_loss",
                "take_profit", "win_probability", "payoff_ratio", "rationale"
            ],
            "additionalProperties": false
        ]
        let body: [String: Any] = [
            "model": model,
            "messages": messages,
            "reasoning_effort": "low",
            "max_completion_tokens": 4096,
            "stream": false,
            "response_format": [
                "type": "json_schema",
                "json_schema": [
                    "name": "trading_decision",
                    "strict": true,
                    "schema": schema
                ]
            ]
        ]

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let data = try await sendWithRetry(request)
        let response = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        guard let choice = response.choices.first else {
            throw QuantSwarmError.invalidServerResponse("Nessuna choice Kimi")
        }
        guard choice.finishReason != "length" else {
            throw QuantSwarmError.invalidServerResponse("JSON Kimi troncato")
        }
        guard let content = choice.message.content, !content.isEmpty else {
            throw QuantSwarmError.invalidServerResponse("Contenuto Kimi vuoto")
        }

        let json = try extractJSONObject(from: content)
        let decision = try JSONDecoder().decode(KimiDecision.self, from: Data(json.utf8))
        guard decision.symbol.uppercased() == snapshot.symbol.uppercased() else {
            throw QuantSwarmError.invalidDecision("Simbolo non corrispondente")
        }
        guard decision.action == .hold || decision.isExecutable else {
            throw QuantSwarmError.invalidDecision("Campi o livelli di prezzo incoerenti")
        }
        return decision
    }

    private func sendWithRetry(_ request: URLRequest) async throws -> Data {
        let retryableStatuses: Set<Int> = [429, 500, 502, 503, 504]
        for attempt in 0..<4 {
            try Task.checkCancellation()
            do {
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse else {
                    throw QuantSwarmError.invalidServerResponse("Risposta non HTTP")
                }
                if (200..<300).contains(http.statusCode) {
                    return data
                }
                let body = String(decoding: data.prefix(1_000), as: UTF8.self)
                if retryableStatuses.contains(http.statusCode), attempt < 3 {
                    try await backoff(attempt: attempt)
                    continue
                }
                throw QuantSwarmError.httpStatus(http.statusCode, body)
            } catch let error as URLError {
                if attempt == 3 { throw error }
                try await backoff(attempt: attempt)
            }
        }
        throw QuantSwarmError.invalidServerResponse("Retry Kimi esauriti")
    }

    private func backoff(attempt: Int) async throws {
        let base = pow(2.0, Double(attempt))
        let nanoseconds = UInt64((base + Double.random(in: 0...0.25)) * 1_000_000_000)
        try await Task.sleep(nanoseconds: nanoseconds)
    }

    private func extractJSONObject(from content: String) throws -> String {
        var sanitized = content.trimmingCharacters(in: .whitespacesAndNewlines)
        let fencePattern = #"(?s)^```(?:json)?\s*(.*?)\s*```$"#
        if let regex = try? NSRegularExpression(pattern: fencePattern) {
            let range = NSRange(sanitized.startIndex..<sanitized.endIndex, in: sanitized)
            if let match = regex.firstMatch(in: sanitized, range: range),
               let bodyRange = Range(match.range(at: 1), in: sanitized) {
                sanitized = String(sanitized[bodyRange])
            }
        }
        guard let start = sanitized.firstIndex(of: "{"),
              let end = sanitized.lastIndex(of: "}"),
              start <= end else {
            throw QuantSwarmError.invalidServerResponse("Nessun oggetto JSON")
        }
        let candidate = String(sanitized[start...end])
        let object = try JSONSerialization.jsonObject(with: Data(candidate.utf8))
        guard object is [String: Any] else {
            throw QuantSwarmError.invalidServerResponse("JSON non è un oggetto")
        }
        return candidate
    }
}

private struct ChatCompletionResponse: Decodable {
    let choices: [Choice]

    struct Choice: Decodable {
        let message: Message
        let finishReason: String?

        enum CodingKeys: String, CodingKey {
            case message
            case finishReason = "finish_reason"
        }
    }

    struct Message: Decodable {
        let content: String?
    }
}
````

### `Sources/Services/AlpacaService.swift`

````swift
import Foundation

struct AlpacaOrder: Decodable, Sendable {
    let id: String
    let status: String
    let symbol: String
    let side: String
    let type: String
    let quantity: String?
    let filledQuantity: String?
    let filledAveragePrice: String?
    let legs: [AlpacaOrder]?

    enum CodingKeys: String, CodingKey {
        case id
        case status
        case symbol
        case side
        case type
        case quantity = "qty"
        case filledQuantity = "filled_qty"
        case filledAveragePrice = "filled_avg_price"
        case legs
    }

    var filledQuantityValue: Double { Double(filledQuantity ?? "0") ?? 0 }
    var filledAveragePriceValue: Double? { Double(filledAveragePrice ?? "") }
}

struct AlpacaPosition: Decodable, Sendable {
    let symbol: String
    let quantity: String

    enum CodingKeys: String, CodingKey {
        case symbol
        case quantity = "qty"
    }
}

actor AlpacaService {
    private let credentials: AlpacaCredentials
    private let session: URLSession

    init(credentials: AlpacaCredentials) {
        self.credentials = credentials
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 45
        configuration.waitsForConnectivity = true
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
    }

    func validateCredentials() async throws {
        _ = try await account()
    }

    func account() async throws -> AccountSnapshot {
        let data = try await send(path: "/v2/account", method: "GET")
        return try JSONDecoder().decode(AccountSnapshot.self, from: data)
    }

    func openOrders() async throws -> [AlpacaOrder] {
        let data = try await send(
            path: "/v2/orders",
            method: "GET",
            query: [URLQueryItem(name: "status", value: "open")]
        )
        return try JSONDecoder().decode([AlpacaOrder].self, from: data)
    }

    func positions() async throws -> [AlpacaPosition] {
        let data = try await send(path: "/v2/positions", method: "GET")
        return try JSONDecoder().decode([AlpacaPosition].self, from: data)
    }

    func order(id: String) async throws -> AlpacaOrder {
        guard let escaped = id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) else {
            throw QuantSwarmError.invalidServerResponse("Order ID non codificabile")
        }
        let data = try await send(path: "/v2/orders/\(escaped)", method: "GET")
        return try JSONDecoder().decode(AlpacaOrder.self, from: data)
    }

    func submitBracket(
        decision: KimiDecision,
        quantity: Double,
        limitPrice: Double
    ) async throws -> AlpacaOrder {
        let body: [String: Any] = [
            "symbol": decision.symbol.uppercased(),
            "qty": decimalString(quantity, fractionDigits: 0),
            "side": decision.action.rawValue,
            "type": "limit",
            "time_in_force": "day",
            "limit_price": decimalString(limitPrice, fractionDigits: 4),
            "order_class": "bracket",
            "client_order_id": "qswarm-\(UUID().uuidString.lowercased())",
            "extended_hours": false,
            "take_profit": [
                "limit_price": decimalString(decision.takeProfit, fractionDigits: 4)
            ],
            "stop_loss": [
                "stop_price": decimalString(decision.stopLoss, fractionDigits: 4)
            ]
        ]
        let data = try await send(path: "/v2/orders", method: "POST", body: body)
        return try JSONDecoder().decode(AlpacaOrder.self, from: data)
    }

    func cancelAllAndFlatten() async throws {
        _ = try await send(path: "/v2/orders", method: "DELETE")
        _ = try await send(path: "/v2/positions", method: "DELETE")
    }

    private func send(
        path: String,
        method: String,
        query: [URLQueryItem] = [],
        body: [String: Any]? = nil
    ) async throws -> Data {
        guard var components = URLComponents(
            url: credentials.tradingBaseURL.appendingPathComponent(path),
            resolvingAgainstBaseURL: false
        ) else {
            throw QuantSwarmError.invalidServerResponse("URL Alpaca non valido")
        }
        if !query.isEmpty { components.queryItems = query }
        guard let url = components.url else {
            throw QuantSwarmError.invalidServerResponse("URL Alpaca non valido")
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(credentials.keyID, forHTTPHeaderField: "APCA-API-KEY-ID")
        request.setValue(credentials.secretKey, forHTTPHeaderField: "APCA-API-SECRET-KEY")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        return try await sendWithRetry(request)
    }

    private func sendWithRetry(_ request: URLRequest) async throws -> Data {
        let retryableStatuses: Set<Int> = [429, 500, 502, 503, 504]
        for attempt in 0..<4 {
            try Task.checkCancellation()
            do {
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse else {
                    throw QuantSwarmError.invalidServerResponse("Risposta Alpaca non HTTP")
                }
                if (200..<300).contains(http.statusCode) {
                    return data
                }
                let message = String(decoding: data.prefix(1_000), as: UTF8.self)
                if retryableStatuses.contains(http.statusCode), attempt < 3 {
                    try await backoff(attempt: attempt)
                    continue
                }
                throw QuantSwarmError.httpStatus(http.statusCode, message)
            } catch let error as URLError {
                if attempt == 3 { throw error }
                try await backoff(attempt: attempt)
            }
        }
        throw QuantSwarmError.invalidServerResponse("Retry Alpaca esauriti")
    }

    private func backoff(attempt: Int) async throws {
        let seconds = pow(2.0, Double(attempt)) + Double.random(in: 0...0.25)
        try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
    }

    private func decimalString(_ value: Double, fractionDigits: Int) -> String {
        String(
            format: "%.\(fractionDigits)f",
            locale: Locale(identifier: "en_US_POSIX"),
            value
        )
    }
}
````

### `Sources/Agents/MarketScoutAgent.swift`

````swift
import Foundation
import Network

enum MarketEvent: Sendable {
    case snapshot(MarketSnapshot)
    case log(String)
    case disconnected(String)
}

actor MarketScoutAgent {
    private var credentials: AlpacaCredentials?
    private var symbols: [String] = []
    private var continuation: AsyncStream<MarketEvent>.Continuation?
    private var lifecycleTask: Task<Void, Never>?
    private var socket: URLSessionWebSocketTask?
    private var running = false
    private var retryAttempt = 0
    private var monitoring = false
    private var atrStates: [String: ATRState] = [:]
    private var lastPrices: [String: Double] = [:]
    private let session: URLSession
    private let pathMonitor = NWPathMonitor()
    private let monitorQueue = DispatchQueue(label: "com.quantswarm.alphazero.network")
    private let fractionalTimestampFormatter = ISO8601DateFormatter()
    private let standardTimestampFormatter = ISO8601DateFormatter()

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForResource = 0
        configuration.waitsForConnectivity = true
        session = URLSession(configuration: configuration)
        fractionalTimestampFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    }

    func start(
        credentials: AlpacaCredentials,
        symbols: [String]
    ) -> AsyncStream<MarketEvent> {
        stop()
        self.credentials = credentials
        self.symbols = Array(Set(symbols.map { $0.uppercased() })).sorted()
        self.atrStates = Dictionary(uniqueKeysWithValues: self.symbols.map { ($0, ATRState()) })
        self.lastPrices = [:]
        self.retryAttempt = 0
        self.running = true
        startNetworkMonitoring()

        return AsyncStream(bufferingPolicy: .bufferingNewest(512)) { continuation in
            self.continuation = continuation
            continuation.onTermination = { @Sendable _ in
                Task { await self.stop() }
            }
            lifecycleTask = Task { await self.run() }
        }
    }

    func stop() {
        running = false
        lifecycleTask?.cancel()
        lifecycleTask = nil
        socket?.cancel(with: .goingAway, reason: nil)
        socket = nil
        continuation?.finish()
        continuation = nil
    }

    private func startNetworkMonitoring() {
        guard !monitoring else { return }
        monitoring = true
        pathMonitor.pathUpdateHandler = { [weak self] path in
            let satisfied = path.status == .satisfied
            Task { await self?.networkStatusChanged(satisfied) }
        }
        pathMonitor.start(queue: monitorQueue)
    }

    private func networkStatusChanged(_ satisfied: Bool) {
        guard running else { return }
        if satisfied {
            continuation?.yield(.log("Rete disponibile: verifica dello stream Alpaca."))
        } else {
            continuation?.yield(.disconnected("Rete assente; stream sospeso."))
            socket?.cancel(with: .goingAway, reason: nil)
        }
    }

    private func run() async {
        while running && !Task.isCancelled {
            do {
                try await connectAndListen()
                if running {
                    throw QuantSwarmError.invalidServerResponse("WebSocket Alpaca chiuso")
                }
            } catch is CancellationError {
                break
            } catch {
                guard running else { break }
                continuation?.yield(.disconnected(error.localizedDescription))
                let seconds = min(60, pow(2.0, Double(retryAttempt))) + Double.random(in: 0...0.5)
                retryAttempt = min(retryAttempt + 1, 6)
                continuation?.yield(.log("Riconnessione tra \(String(format: "%.1f", seconds)) s."))
                do {
                    try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                } catch {
                    break
                }
            }
        }
    }

    private func connectAndListen() async throws {
        guard let credentials, !symbols.isEmpty else {
            throw QuantSwarmError.credentialsMissing
        }
        let task = session.webSocketTask(with: credentials.marketDataStreamURL)
        socket = task
        task.resume()
        defer { socket = nil }

        let connected = try await receiveMessages(from: task)
        guard connected.contains(where: { $0.type == "success" && $0.message == "connected" }) else {
            throw QuantSwarmError.invalidServerResponse("Handshake Alpaca non riuscito")
        }

        try await sendJSONObject([
            "action": "auth",
            "key": credentials.keyID,
            "secret": credentials.secretKey
        ], over: task)

        let authentication = try await receiveMessages(from: task)
        if let error = authentication.first(where: { $0.type == "error" }) {
            throw QuantSwarmError.httpStatus(error.code ?? 401, error.message ?? "Autenticazione stream")
        }
        guard authentication.contains(where: {
            $0.type == "success" && $0.message == "authenticated"
        }) else {
            throw QuantSwarmError.invalidServerResponse("Autenticazione stream non riuscita")
        }

        try await sendJSONObject([
            "action": "subscribe",
            "trades": symbols,
            "bars": symbols
        ], over: task)
        retryAttempt = 0
        continuation?.yield(.log("Stream Alpaca autenticato: \(symbols.joined(separator: ", "))."))

        while running && !Task.isCancelled {
            let messages = try await receiveMessages(from: task)
            for message in messages {
                if let error = message.errorDescription {
                    continuation?.yield(.log("Alpaca stream: \(error)"))
                    continue
                }
                try process(message)
            }
        }
    }

    private func sendJSONObject(
        _ object: [String: Any],
        over task: URLSessionWebSocketTask
    ) async throws {
        let data = try JSONSerialization.data(withJSONObject: object)
        try await task.send(.string(String(decoding: data, as: UTF8.self)))
    }

    private func receiveMessages(from task: URLSessionWebSocketTask) async throws -> [StreamMessage] {
        let data: Data
        switch try await task.receive() {
        case .data(let receivedData):
            data = receivedData
        case .string(let text):
            data = Data(text.utf8)
        @unknown default:
            throw QuantSwarmError.invalidServerResponse("Frame WebSocket sconosciuto")
        }
        return try JSONDecoder().decode([StreamMessage].self, from: data)
    }

    private func process(_ message: StreamMessage) throws {
        guard let symbol = message.symbol else { return }
        let receivedAt = Date()
        let sourceTimestamp = message.timestamp.flatMap(parseTimestamp) ?? receivedAt

        if message.type == "b",
           let open = message.open,
           let high = message.high,
           let low = message.low,
           let close = message.close {
            var state = atrStates[symbol] ?? ATRState()
            let atr = state.update(open: open, high: high, low: low, close: close)
            atrStates[symbol] = state
            lastPrices[symbol] = close
            continuation?.yield(.snapshot(MarketSnapshot(
                symbol: symbol,
                lastPrice: close,
                atr14: atr,
                sourceTimestamp: sourceTimestamp,
                receivedAt: receivedAt
            )))
            return
        }

        if message.type == "t", let price = message.price {
            lastPrices[symbol] = price
            continuation?.yield(.snapshot(MarketSnapshot(
                symbol: symbol,
                lastPrice: price,
                atr14: atrStates[symbol]?.atr,
                sourceTimestamp: sourceTimestamp,
                receivedAt: receivedAt
            )))
        }
    }

    private func parseTimestamp(_ value: String) -> Date? {
        fractionalTimestampFormatter.date(from: value)
            ?? standardTimestampFormatter.date(from: value)
    }
}

private struct ATRState {
    private var initialTrueRanges: [Double] = []
    private var previousClose: Double?
    private(set) var atr: Double?

    mutating func update(open: Double, high: Double, low: Double, close: Double) -> Double? {
        let trueRange: Double
        if let previousClose {
            trueRange = max(
                high - low,
                abs(high - previousClose),
                abs(low - previousClose)
            )
        } else {
            trueRange = high - low
        }
        previousClose = close

        if let currentATR = atr {
            atr = ((currentATR * 13) + trueRange) / 14
        } else {
            initialTrueRanges.append(trueRange)
            if initialTrueRanges.count == 14 {
                atr = initialTrueRanges.reduce(0, +) / 14
                initialTrueRanges.removeAll(keepingCapacity: false)
            }
        }
        return atr
    }
}

private struct StreamMessage: Decodable {
    let type: String
    let message: String?
    let code: Int?
    let symbol: String?
    let price: Double?
    let open: Double?
    let high: Double?
    let low: Double?
    let close: Double?
    let timestamp: String?

    enum CodingKeys: String, CodingKey {
        case type = "T"
        case message = "msg"
        case code
        case symbol = "S"
        case price = "p"
        case open = "o"
        case high = "h"
        case low = "l"
        case close = "c"
        case timestamp = "t"
    }

    var errorDescription: String? {
        guard type == "error" else { return nil }
        return "\(code ?? 0): \(message ?? "errore sconosciuto")"
    }
}
````

### `Sources/Agents/RiskExecutionAgent.swift`

````swift
import Foundation

actor RiskExecutionAgent {
    private let maximumRiskFraction = 0.01
    private let fractionalKellyDivisor = 4.0
    private let maximumLatencyMilliseconds = 150.0
    private let maximumPriceDeviation = 0.0005

    func execute(
        decision: KimiDecision,
        snapshot: MarketSnapshot,
        credentials: AlpacaCredentials
    ) async throws -> ExecutionReceipt? {
        guard decision.action != .hold else { return nil }
        guard decision.isExecutable else {
            throw QuantSwarmError.riskRejected("Segnale non eseguibile o livelli incoerenti")
        }
        guard decision.symbol.uppercased() == snapshot.symbol.uppercased() else {
            throw QuantSwarmError.riskRejected("Snapshot e segnale hanno simboli diversi")
        }
        guard snapshot.feedLatencyMilliseconds <= maximumLatencyMilliseconds else {
            throw QuantSwarmError.riskRejected("Feed oltre 150 ms")
        }

        let deviation = abs(snapshot.lastPrice - decision.entryPrice) / decision.entryPrice
        guard deviation <= maximumPriceDeviation else {
            throw QuantSwarmError.riskRejected("Prezzo spostato oltre lo 0,05%")
        }

        let service = AlpacaService(credentials: credentials)
        async let openOrdersRequest = service.openOrders()
        async let positionsRequest = service.positions()
        let (openOrders, positions) = try await (openOrdersRequest, positionsRequest)
        guard !openOrders.contains(where: { $0.symbol == decision.symbol.uppercased() }),
              !positions.contains(where: { $0.symbol == decision.symbol.uppercased() }) else {
            throw QuantSwarmError.riskRejected("Posizione o ordine già presente sul simbolo")
        }

        let clock = ContinuousClock()
        let start = clock.now
        let account = try await service.account()
        let elapsed = start.duration(to: clock.now).components
        let latency = Double(elapsed.seconds) * 1_000
            + Double(elapsed.attoseconds) / 1_000_000_000_000_000
        guard latency <= maximumLatencyMilliseconds else {
            throw QuantSwarmError.riskRejected("Latenza REST \(latency) ms oltre 150 ms")
        }
        guard !account.tradingBlocked, !account.tradeSuspendedByEmail else {
            throw QuantSwarmError.riskRejected("Trading bloccato sul conto Alpaca")
        }
        guard account.equityValue > 0 else {
            throw QuantSwarmError.riskRejected("Patrimonio non positivo")
        }

        let limitPrice = decision.action == .buy
            ? decision.entryPrice * (1 + maximumPriceDeviation)
            : decision.entryPrice * (1 - maximumPriceDeviation)
        let riskPerShare = abs(limitPrice - decision.stopLoss)
        guard riskPerShare > 0 else {
            throw QuantSwarmError.riskRejected("Distanza stop nulla")
        }

        let probability = decision.winProbability
        let payoff = decision.payoffRatio
        let fullKelly = max(0, probability - ((1 - probability) / payoff))
        let fractionalKelly = fullKelly / fractionalKellyDivisor
        guard fractionalKelly > 0 else {
            throw QuantSwarmError.riskRejected("Kelly frazionato non positivo")
        }

        let riskBudget = account.equityValue * maximumRiskFraction
        let riskQuantity = riskBudget / riskPerShare
        let kellyQuantity = (account.equityValue * fractionalKelly) / limitPrice
        let availableCapital = decision.action == .buy
            ? min(account.cashValue, account.buyingPowerValue)
            : account.buyingPowerValue
        let capitalQuantity = availableCapital / limitPrice
        let quantity = floor(min(riskQuantity, kellyQuantity, capitalQuantity))
        guard quantity >= 1 else {
            throw QuantSwarmError.riskRejected("Quantità inferiore a un'azione intera")
        }
        guard quantity * riskPerShare <= riskBudget + 0.000_001 else {
            throw QuantSwarmError.riskRejected("Rischio calcolato oltre l'1%")
        }

        let order = try await service.submitBracket(
            decision: decision,
            quantity: quantity,
            limitPrice: limitPrice
        )
        return ExecutionReceipt(
            orderID: order.id,
            decision: decision,
            quantity: quantity,
            equity: account.equityValue,
            measuredLatencyMilliseconds: latency
        )
    }

    func emergencyFlatten(credentials: AlpacaCredentials) async throws {
        let service = AlpacaService(credentials: credentials)
        try await service.cancelAllAndFlatten()
    }
}
````

### `Sources/Core/BackgroundPersistenceManager.swift`

````swift
import BackgroundTasks
import CoreLocation
import UIKit

@MainActor
final class BackgroundPersistenceManager: NSObject, CLLocationManagerDelegate {
    static let refreshIdentifier = "com.quantswarm.alphazero.refresh"
    private static var didRegister = false

    private let locationManager = CLLocationManager()
    private var running = false
    private var refreshHandler: (@MainActor () async -> Void)?

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 100
        locationManager.pausesLocationUpdatesAutomatically = false
        locationManager.showsBackgroundLocationIndicator = true
    }

    func registerBackgroundTasks() {
        guard !Self.didRegister else { return }
        Self.didRegister = true
        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: Self.refreshIdentifier,
            using: nil
        ) { [weak self] task in
            guard let refreshTask = task as? BGAppRefreshTask else {
                task.setTaskCompleted(withSuccess: false)
                return
            }
            Task { @MainActor in
                await self?.handleBackgroundTask(refreshTask)
            }
        }
    }

    func setRefreshHandler(_ handler: @escaping @MainActor () async -> Void) {
        refreshHandler = handler
    }

    func start() {
        guard !running else { return }
        running = true
        scheduleNextRefresh()
        applyLocationAuthorization()
        UIApplication.shared.registerForRemoteNotifications()
    }

    func stop() {
        running = false
        BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: Self.refreshIdentifier)
        locationManager.stopUpdatingLocation()
        locationManager.allowsBackgroundLocationUpdates = false
    }

    private func applyLocationAuthorization() {
        guard running else { return }
        switch locationManager.authorizationStatus {
        case .authorizedAlways:
            locationManager.allowsBackgroundLocationUpdates = true
            locationManager.startUpdatingLocation()
        case .authorizedWhenInUse:
            locationManager.allowsBackgroundLocationUpdates = false
            locationManager.startUpdatingLocation()
        case .notDetermined:
            locationManager.requestAlwaysAuthorization()
        case .denied, .restricted:
            locationManager.stopUpdatingLocation()
        @unknown default:
            locationManager.stopUpdatingLocation()
        }
    }

    private func scheduleNextRefresh() {
        guard running else { return }
        let request = BGAppRefreshTaskRequest(identifier: Self.refreshIdentifier)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            NSLog("BGTaskScheduler submit failed: \(error.localizedDescription)")
        }
    }

    private func handleBackgroundTask(_ task: BGAppRefreshTask) async {
        scheduleNextRefresh()
        guard running else {
            task.setTaskCompleted(withSuccess: false)
            return
        }
        let operation = Task { @MainActor in
            await refreshHandler?()
        }
        task.expirationHandler = {
            operation.cancel()
        }
        await operation.value
        task.setTaskCompleted(withSuccess: !operation.isCancelled)
    }

    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor [weak self] in
            self?.applyLocationAuthorization()
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        NSLog("Location update failed: \(error.localizedDescription)")
    }
}
````

### `Sources/Core/QuantSwarmEngine.swift`

````swift
import Foundation
import SwiftData

struct AgentLogEntry: Identifiable, Sendable {
    let id = UUID()
    let timestamp: Date
    let message: String
}

@MainActor
final class QuantSwarmEngine: ObservableObject {
    @Published private(set) var isConfigured = false
    @Published private(set) var isRunning = false
    @Published private(set) var isKillInProgress = false
    @Published private(set) var paperTrading = true
    @Published private(set) var statusMessage = "Credenziali richieste"
    @Published private(set) var logs: [AgentLogEntry] = []
    @Published private(set) var edgeHistory: [EdgePoint] = []

    private let keychain: KeychainManager
    private let background: BackgroundPersistenceManager
    private let modelContext: ModelContext
    private let marketScout = MarketScoutAgent()
    private let riskAgent = RiskExecutionAgent()
    private var kimiService: KimiService?
    private var credentials: StoredCredentials?
    private var analysisTask: Task<Void, Never>?
    private var marketTask: Task<Void, Never>?
    private var snapshots: [String: MarketSnapshot] = [:]
    private var configuredSymbols: [String] = ["SPY"]
    private var configuredNews = ""
    private var baselineEquity: Double?
    private var waitingLogEmitted: Set<String> = []

    init(
        keychain: KeychainManager,
        background: BackgroundPersistenceManager,
        container: ModelContainer
    ) {
        self.keychain = keychain
        self.background = background
        modelContext = ModelContext(container)
        background.setRefreshHandler { [weak self] in
            await self?.performBackgroundRefresh()
        }
    }

    func restoreCredentials() async {
        do {
            let data = try await keychain.read()
            let stored = try JSONDecoder().decode(StoredCredentials.self, from: data)
            apply(stored: stored)
            log("Credenziali sbloccate; ambiente \(stored.paperTrading ? "paper" : "live").")
        } catch QuantSwarmError.credentialsMissing {
            isConfigured = false
            statusMessage = "Credenziali richieste"
        } catch {
            isConfigured = false
            statusMessage = "Sblocco credenziali annullato o non riuscito"
            log(error.localizedDescription)
        }
    }

    func validateAndSave(
        moonshotAPIKey: String,
        alpacaKeyID: String,
        alpacaSecretKey: String,
        paperTrading: Bool
    ) async throws {
        let moonshot = moonshotAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let alpacaID = alpacaKeyID.trimmingCharacters(in: .whitespacesAndNewlines)
        let alpacaSecret = alpacaSecretKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !moonshot.isEmpty, !alpacaID.isEmpty, !alpacaSecret.isEmpty else {
            throw QuantSwarmError.invalidCredentialInput
        }
        let stored = StoredCredentials(
            moonshotAPIKey: moonshot,
            alpacaKeyID: alpacaID,
            alpacaSecretKey: alpacaSecret,
            paperTrading: paperTrading
        )
        let kimi = KimiService(apiKey: moonshot)
        let alpaca = AlpacaService(credentials: stored.alpaca)
        async let kimiValidation: Void = kimi.validateCredentials()
        async let alpacaValidation: Void = alpaca.validateCredentials()
        _ = try await (kimiValidation, alpacaValidation)
        let data = try JSONEncoder().encode(stored)
        try await keychain.save(data: data)
        apply(stored: stored)
        log("API Kimi e Alpaca convalidate; credenziali salvate con Face ID.")
    }

    func logout() async {
        await stop()
        try? await keychain.delete()
        credentials = nil
        kimiService = nil
        isConfigured = false
        baselineEquity = nil
        edgeHistory = []
        statusMessage = "Credenziali richieste"
    }

    func start(symbolsText: String, news: String) async {
        guard let credentials, let kimiService else {
            statusMessage = "Credenziali mancanti"
            return
        }
        guard !isRunning else { return }
        let parsedSymbols = Array(Set(
            symbolsText
                .uppercased()
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
        )).sorted()
        guard !parsedSymbols.isEmpty else {
            statusMessage = "Inserisci almeno un simbolo"
            return
        }
        let validCharacters = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-")
        guard parsedSymbols.allSatisfy({ $0.rangeOfCharacter(from: validCharacters.inverted) == nil }) else {
            statusMessage = "Simboli non validi"
            return
        }

        configuredSymbols = parsedSymbols
        configuredNews = news.trimmingCharacters(in: .whitespacesAndNewlines)
        snapshots = [:]
        waitingLogEmitted = []
        isRunning = true
        statusMessage = "Sessione \(credentials.paperTrading ? "paper" : "live") attiva"
        background.start()
        log("Motore avviato su \(parsedSymbols.joined(separator: ", ")); ATR richiesto prima dei segnali.")

        let stream = await marketScout.start(
            credentials: credentials.alpaca,
            symbols: parsedSymbols
        )
        marketTask = Task { [weak self] in
            for await event in stream {
                self?.handle(event)
            }
        }
        analysisTask = Task { [weak self] in
            await self?.analysisLoop(kimi: kimiService)
        }
    }

    func stop() async {
        guard isRunning || analysisTask != nil || marketTask != nil else { return }
        isRunning = false
        analysisTask?.cancel()
        marketTask?.cancel()
        analysisTask = nil
        marketTask = nil
        await marketScout.stop()
        background.stop()
        statusMessage = "Motore fermo; posizioni invariate"
        log("Motore fermato. Usa HARD KILL SWITCH per liquidare le posizioni.")
    }

    func hardKill() async {
        guard !isKillInProgress else { return }
        isKillInProgress = true
        defer { isKillInProgress = false }
        await stop()
        statusMessage = "Liquidazione di emergenza in corso"
        log("HARD KILL: cancellazione ordini e liquidazione avviate.")
        guard let credentials else {
            statusMessage = "Credenziali mancanti"
            return
        }
        do {
            try await riskAgent.emergencyFlatten(credentials: credentials.alpaca)
            statusMessage = "HARD KILL completato"
            log("Alpaca ha accettato cancellazione globale e chiusura delle posizioni.")
            await updateEquity()
        } catch {
            statusMessage = "HARD KILL: verifica immediata sul broker"
            log("HARD KILL errore: \(error.localizedDescription)")
        }
    }

    private func apply(stored: StoredCredentials) {
        credentials = stored
        kimiService = KimiService(apiKey: stored.moonshotAPIKey)
        paperTrading = stored.paperTrading
        isConfigured = true
        statusMessage = "Pronto in modalità \(stored.paperTrading ? "paper" : "live")"
    }

    private func handle(_ event: MarketEvent) {
        switch event {
        case .snapshot(let snapshot):
            snapshots[snapshot.symbol] = snapshot
        case .log(let message):
            log(message)
        case .disconnected(let message):
            statusMessage = "Stream disconnesso"
            log(message)
        }
    }

    private func analysisLoop(kimi: KimiService) async {
        while isRunning && !Task.isCancelled {
            await refreshTradeRecords()
            await updateEquity()
            for symbol in configuredSymbols {
                guard isRunning && !Task.isCancelled else { break }
                guard let snapshot = snapshots[symbol], snapshot.atr14 != nil else {
                    if !waitingLogEmitted.contains(symbol) {
                        waitingLogEmitted.insert(symbol)
                        log("\(symbol): attesa di 14 barre per ATR e prezzi correnti.")
                    }
                    continue
                }
                waitingLogEmitted.remove(symbol)
                do {
                    let decision = try await kimi.decide(
                        snapshot: snapshot,
                        news: configuredNews,
                        performance: performanceMatrix()
                    )
                    log("\(symbol): Kimi \(decision.action.rawValue.uppercased()), confidenza \(decision.confidence).")
                    if let receipt = try await riskAgent.execute(
                        decision: decision,
                        snapshot: snapshot,
                        credentials: credentials!.alpaca
                    ) {
                        try persist(receipt: receipt, atr: snapshot.atr14 ?? 0)
                        log("Bracket inviato: \(orderDescription(receipt)).")
                    }
                } catch is CancellationError {
                    return
                } catch QuantSwarmError.riskRejected(let reason) {
                    log("\(symbol): ordine annullato — \(reason).")
                } catch {
                    log("\(symbol): \(error.localizedDescription)")
                }
            }
            do {
                try await Task.sleep(nanoseconds: 60_000_000_000)
            } catch {
                return
            }
        }
    }

    private func performBackgroundRefresh() async {
        guard credentials != nil else { return }
        await refreshTradeRecords()
        await updateEquity()
        log("Refresh BGTask completato nei limiti concessi da iOS.")
    }

    private func persist(receipt: ExecutionReceipt, atr: Double) throws {
        modelContext.insert(TradeRecord(receipt: receipt, atr: atr))
        do {
            try modelContext.save()
        } catch {
            throw QuantSwarmError.persistence(error.localizedDescription)
        }
    }

    private func refreshTradeRecords() async {
        guard let credentials else { return }
        let service = AlpacaService(credentials: credentials.alpaca)
        do {
            var descriptor = FetchDescriptor<TradeRecord>(
                sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
            )
            descriptor.fetchLimit = 100
            let records = try modelContext.fetch(descriptor).filter { !$0.outcomeRecorded }
            for record in records {
                do {
                    let order = try await service.order(id: record.orderID)
                    if let entry = order.filledAveragePriceValue {
                        record.actualEntry = entry
                    }
                    guard let entry = record.actualEntry,
                          let exit = order.legs?.first(where: {
                              $0.side != order.side
                                  && $0.filledQuantityValue > 0
                                  && $0.filledAveragePriceValue != nil
                          }),
                          let exitPrice = exit.filledAveragePriceValue else {
                        continue
                    }
                    let quantity = exit.filledQuantityValue
                    let direction = order.side == "buy" ? 1.0 : -1.0
                    record.netPnL = (exitPrice - entry) * quantity * direction
                    if exit.type == "stop" || exit.type == "stop_limit" {
                        record.stopErrorVariance = pow(exitPrice - record.stopLoss, 2)
                    }
                    record.outcomeRecorded = true
                    log("Esito \(record.symbol): P&L \(record.netPnL ?? 0).")
                } catch {
                    log("Aggiornamento ordine \(record.orderID): \(error.localizedDescription)")
                }
            }
            if !records.isEmpty { try modelContext.save() }
        } catch {
            log("SwiftData refresh: \(error.localizedDescription)")
        }
    }

    private func performanceMatrix() -> PerformanceMatrix {
        let descriptor = FetchDescriptor<TradeRecord>(
            sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
        )
        guard let records = try? modelContext.fetch(descriptor) else {
            return PerformanceMatrix(
                submittedTrades: 0,
                completedTrades: 0,
                winRate: nil,
                averageNetPnL: nil,
                stopErrorVariance: nil,
                recentOutcomes: []
            )
        }
        let outcomes = records.compactMap(\.netPnL)
        let completed = records.filter(\.outcomeRecorded)
        let wins = outcomes.filter { $0 > 0 }.count
        let stopErrors = records.compactMap(\.stopErrorVariance)
        return PerformanceMatrix(
            submittedTrades: records.count,
            completedTrades: completed.count,
            winRate: outcomes.isEmpty ? nil : Double(wins) / Double(outcomes.count),
            averageNetPnL: outcomes.isEmpty ? nil : outcomes.reduce(0, +) / Double(outcomes.count),
            stopErrorVariance: stopErrors.isEmpty ? nil : stopErrors.reduce(0, +) / Double(stopErrors.count),
            recentOutcomes: Array(outcomes.prefix(20))
        )
    }

    private func updateEquity() async {
        guard let credentials else { return }
        do {
            let account = try await AlpacaService(credentials: credentials.alpaca).account()
            if baselineEquity == nil { baselineEquity = account.equityValue }
            let edge = account.equityValue - (baselineEquity ?? account.equityValue)
            edgeHistory.append(EdgePoint(timestamp: Date(), value: edge))
            if edgeHistory.count > 500 { edgeHistory.removeFirst(edgeHistory.count - 500) }
            if !isRunning { statusMessage = "Equity \(account.equityValue) USD" }
        } catch {
            log("Equity: \(error.localizedDescription)")
        }
    }

    private func orderDescription(_ receipt: ExecutionReceipt) -> String {
        "\(receipt.decision.symbol) \(receipt.decision.action.rawValue) qty \(receipt.quantity), latenza \(receipt.measuredLatencyMilliseconds) ms"
    }

    private func log(_ message: String) {
        logs.append(AgentLogEntry(timestamp: Date(), message: message))
        if logs.count > 300 { logs.removeFirst(logs.count - 300) }
    }
}
````

### `Sources/Views/LoginView.swift`

````swift
import SwiftUI

struct LoginView: View {
    @EnvironmentObject private var engine: QuantSwarmEngine
    @State private var moonshotAPIKey = ""
    @State private var alpacaKeyID = ""
    @State private var alpacaSecretKey = ""
    @State private var paperTrading = true
    @State private var validating = false
    @State private var errorMessage: String?

    private let terminalGreen = Color(red: 0.1, green: 1.0, blue: 0.55)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("QUANTSWARM // ALPHA ZERO")
                            .font(.system(.title2, design: .monospaced, weight: .bold))
                            .foregroundStyle(terminalGreen)
                        Text("KIMI DECISION CORE · ALPACA EXECUTION")
                            .font(.system(.caption, design: .monospaced))
                            .foregroundStyle(.gray)
                    }

                    credentialField(title: "MOONSHOT / KIMI API KEY", text: $moonshotAPIKey)
                    credentialField(title: "ALPACA KEY ID", text: $alpacaKeyID)
                    credentialField(title: "ALPACA SECRET KEY", text: $alpacaSecretKey)

                    VStack(alignment: .leading, spacing: 8) {
                        Toggle("PAPER TRADING", isOn: $paperTrading)
                            .font(.system(.callout, design: .monospaced, weight: .bold))
                            .tint(terminalGreen)
                        Text(paperTrading
                             ? "Ordini inviati all'ambiente paper Alpaca."
                             : "ATTENZIONE: ordini su capitale reale. Verifica prima in paper trading.")
                            .font(.system(.caption, design: .monospaced))
                            .foregroundStyle(paperTrading ? .gray : .red)
                    }

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.system(.caption, design: .monospaced))
                            .foregroundStyle(.red)
                            .textSelection(.enabled)
                    }

                    Button {
                        validate()
                    } label: {
                        HStack {
                            Spacer()
                            if validating {
                                ProgressView().tint(.black)
                            } else {
                                Text("VALIDA · FACE ID · SBLOCCA")
                                    .font(.system(.body, design: .monospaced, weight: .bold))
                            }
                            Spacer()
                        }
                        .padding()
                        .background(terminalGreen)
                        .foregroundStyle(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    .disabled(validating || moonshotAPIKey.isEmpty || alpacaKeyID.isEmpty || alpacaSecretKey.isEmpty)
                    .opacity(validating ? 0.6 : 1)

                    Text("Le credenziali sono salvate come generic password nel Keychain con protezione biometrica e accessibilità ThisDeviceOnly. Il Keychain non rende le API key chiavi private del Secure Enclave.")
                        .font(.system(.caption2, design: .monospaced))
                        .foregroundStyle(.gray)
                }
                .padding(24)
            }
        }
    }

    private func credentialField(title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(.caption, design: .monospaced, weight: .bold))
                .foregroundStyle(terminalGreen)
            SecureField("INSERISCI CREDENZIALE", text: text)
                .font(.system(.body, design: .monospaced))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(12)
                .background(Color(white: 0.08))
                .overlay(Rectangle().stroke(terminalGreen.opacity(0.55), lineWidth: 1))
        }
    }

    private func validate() {
        guard !validating else { return }
        validating = true
        errorMessage = nil
        Task {
            do {
                try await engine.validateAndSave(
                    moonshotAPIKey: moonshotAPIKey,
                    alpacaKeyID: alpacaKeyID,
                    alpacaSecretKey: alpacaSecretKey,
                    paperTrading: paperTrading
                )
                moonshotAPIKey = ""
                alpacaKeyID = ""
                alpacaSecretKey = ""
            } catch {
                errorMessage = error.localizedDescription
            }
            validating = false
        }
    }
}
````

### `Sources/Views/TerminalDashboardView.swift`

````swift
import SwiftUI

struct TerminalDashboardView: View {
    @EnvironmentObject private var engine: QuantSwarmEngine
    @State private var symbols = "SPY"
    @State private var news = ""
    @State private var showKillConfirmation = false

    private let terminalGreen = Color(red: 0.1, green: 1.0, blue: 0.55)

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        statusPanel
                        edgePanel
                        controlPanel
                        logPanel
                        killButton
                    }
                    .padding()
                }
            }
            .navigationTitle("QUANTSWARM")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.black, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("LOGOUT") {
                        Task { await engine.logout() }
                    }
                    .font(.system(.caption, design: .monospaced))
                    .foregroundStyle(terminalGreen)
                    .disabled(engine.isKillInProgress)
                }
            }
            .alert("HARD KILL SWITCH", isPresented: $showKillConfirmation) {
                Button("ANNULLA", role: .cancel) {}
                Button("LIQUIDA TUTTO", role: .destructive) {
                    Task { await engine.hardKill() }
                }
            } message: {
                Text("Ferma il motore, cancella tutti gli ordini e richiede ad Alpaca la chiusura a mercato di tutte le posizioni del conto configurato.")
            }
        }
    }

    private var statusPanel: some View {
        HStack {
            Circle()
                .fill(engine.isRunning ? terminalGreen : .gray)
                .frame(width: 10, height: 10)
            VStack(alignment: .leading, spacing: 4) {
                Text(engine.paperTrading ? "PAPER ENVIRONMENT" : "LIVE CAPITAL")
                    .font(.system(.caption, design: .monospaced, weight: .bold))
                    .foregroundStyle(engine.paperTrading ? terminalGreen : .red)
                Text(engine.statusMessage)
                    .font(.system(.caption2, design: .monospaced))
                    .foregroundStyle(.gray)
            }
            Spacer()
        }
        .panelStyle(terminalGreen)
    }

    private var edgePanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("EDGE · EQUITY DELTA USD")
                .font(.system(.caption, design: .monospaced, weight: .bold))
                .foregroundStyle(terminalGreen)
            EdgeChart(points: engine.edgeHistory, color: terminalGreen)
                .frame(height: 180)
        }
        .panelStyle(terminalGreen)
    }

    private var controlPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("SYMBOLS · COMMA SEPARATED")
                .font(.system(.caption2, design: .monospaced))
                .foregroundStyle(.gray)
            TextField("SPY,QQQ", text: $symbols)
                .font(.system(.body, design: .monospaced))
                .textInputAutocapitalization(.characters)
                .autocorrectionDisabled()
                .padding(10)
                .background(Color(white: 0.08))
                .disabled(engine.isRunning)

            Text("NEWS / SENTIMENT INPUT")
                .font(.system(.caption2, design: .monospaced))
                .foregroundStyle(.gray)
            ZStack(alignment: .topLeading) {
                TextEditor(text: $news)
                    .font(.system(.caption, design: .monospaced))
                    .scrollContentBackground(.hidden)
                    .background(Color(white: 0.08))
                    .frame(height: 80)
                    .disabled(engine.isRunning)
                if news.isEmpty {
                    Text("Incolla notizie con data e fonte; nessun feed news automatico.")
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.gray)
                        .padding(8)
                        .allowsHitTesting(false)
                }
            }

            HStack(spacing: 12) {
                Button("START") {
                    Task { await engine.start(symbolsText: symbols, news: news) }
                }
                .buttonStyle(TerminalButtonStyle(color: terminalGreen))
                .disabled(engine.isRunning || engine.isKillInProgress)

                Button("STOP") {
                    Task { await engine.stop() }
                }
                .buttonStyle(TerminalButtonStyle(color: .orange))
                .disabled(!engine.isRunning || engine.isKillInProgress)
            }
        }
        .panelStyle(terminalGreen)
    }

    private var logPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("ATOMIC AGENT LOG")
                .font(.system(.caption, design: .monospaced, weight: .bold))
                .foregroundStyle(terminalGreen)
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 6) {
                        ForEach(engine.logs) { entry in
                            Text("\(entry.timestamp.formatted(date: .omitted, time: .standard))  \(entry.message)")
                                .font(.system(.caption2, design: .monospaced))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .id(entry.id)
                        }
                    }
                }
                .frame(height: 220)
                .onChange(of: engine.logs.count) { _, _ in
                    if let id = engine.logs.last?.id {
                        withAnimation { proxy.scrollTo(id, anchor: .bottom) }
                    }
                }
            }
        }
        .panelStyle(terminalGreen)
    }

    private var killButton: some View {
        Button {
            showKillConfirmation = true
        } label: {
            Text("HARD KILL SWITCH")
                .font(.system(.headline, design: .monospaced, weight: .black))
                .frame(maxWidth: .infinity)
                .padding()
                .background(engine.isKillInProgress ? Color.gray : Color.red)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 6))
        }
        .disabled(engine.isKillInProgress)
        .accessibilityHint("Richiede conferma prima di liquidare tutte le posizioni")
    }
}

private struct EdgeChart: View {
    let points: [EdgePoint]
    let color: Color

    var body: some View {
        Canvas { context, size in
            let gridPath = Path { path in
                for index in 0...4 {
                    let y = size.height * Double(index) / 4
                    path.move(to: CGPoint(x: 0, y: y))
                    path.addLine(to: CGPoint(x: size.width, y: y))
                }
            }
            context.stroke(gridPath, with: .color(.gray.opacity(0.25)), lineWidth: 0.5)

            guard !points.isEmpty else {
                context.draw(
                    Text("ATTESA DATI EQUITY").font(.system(.caption, design: .monospaced)),
                    at: CGPoint(x: size.width / 2, y: size.height / 2)
                )
                return
            }

            let values = points.map(\.value)
            let minimum = min(values.min() ?? 0, 0)
            let maximum = max(values.max() ?? 0, 0)
            let span = max(maximum - minimum, 0.000_001)
            let line = Path { path in
                for (index, point) in points.enumerated() {
                    let x = points.count == 1
                        ? size.width / 2
                        : size.width * Double(index) / Double(points.count - 1)
                    let y = size.height - ((point.value - minimum) / span) * size.height
                    if index == 0 { path.move(to: CGPoint(x: x, y: y)) }
                    else { path.addLine(to: CGPoint(x: x, y: y)) }
                }
            }
            context.stroke(line, with: .color(color), style: StrokeStyle(lineWidth: 2, lineJoin: .round))
        }
        .background(Color(white: 0.04))
        .overlay(Rectangle().stroke(color.opacity(0.4), lineWidth: 1))
    }
}

private struct TerminalButtonStyle: ButtonStyle {
    let color: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(.body, design: .monospaced, weight: .bold))
            .frame(maxWidth: .infinity)
            .padding()
            .background(color.opacity(configuration.isPressed ? 0.35 : 0.18))
            .foregroundStyle(color)
            .overlay(Rectangle().stroke(color, lineWidth: 1))
    }
}

private extension View {
    func panelStyle(_ color: Color) -> some View {
        padding()
            .background(Color(white: 0.06))
            .overlay(Rectangle().stroke(color.opacity(0.35), lineWidth: 1))
    }
}
````

## Verifica e avvio

Le configurazioni YAML e la completezza dei file sono state verificate staticamente. La compilazione iOS richiede Xcode/macOS e viene eseguita dal workflow incluso al push su `main`. Le istruzioni operative, i limiti e i riferimenti ufficiali sono nel file `README.md` riportato sopra.
